=== WP Grins ===
Tags: clickable, smilies, comments, admin, wpgrins
Contributors: alexkingorg
Requires at least: 2.0
Tested up to: 2.1
Stable tag: 1.5

WP Grins will provide clickable smilies for both the post form in the admin interface and the comments form of your blog.

== Installation ==

1. Download the plugin archive and expand it (you've likely already done this).
2. Put the 'wp-grins.php' file into your wp-content/plugins/ directory.
3. Go to the Plugins page in your WordPress Administration area and click 'Activate' for WP Grins.
4. If you are using a version of WP prior to 2.1, upload the included prototype.js to your wp-includes/js/ directory.


== Usage ==

Click on the smilies icons to insert their tags into the text field.


== Known Issues ==

Your theme must include the `wp_head` call and the comments field in your theme must have an id of `comment`;


== Frequently Asked Questions ==

= Why don't the smilies show up in my comments form? =

See the Known Issues above.


= Anything else? =

That about does it - enjoy!

--Alex King

http://alexking.org/projects/wordpress
